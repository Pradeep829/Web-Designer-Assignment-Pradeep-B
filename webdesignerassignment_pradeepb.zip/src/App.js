import React, { useEffect } from 'react';
import styles from './app.module.css';
import AOS from 'aos';
import 'aos/dist/aos.css';

const content = {
  hero: {
    title: 'Discover Our New Collection',
    subtitle: 'Elevate your style with our premium products.',
    buttonText: 'Shop Now',
  },
  products: [
    { id: 1, name: 'Altiplano Ultimate', price: '$29.99', imageUrl: 'altiplano.webp' },
    { id: 2, name: 'Finissimo', price: '$49.99', imageUrl: 'finissimo.webp' },
    { id: 3, name: 'Casio', price: '$19.99', imageUrl: 'casio.webp' },
    { id: 4, name: 'Fastrack', price: '$39.99', imageUrl: 'fastrack.webp' }
  ],
  categories: [
    { name: 'Apparel', imageUrl: 'apparel.jpg' },
    { name: 'Electronics', imageUrl: 'electronics.jpg' },
    { name: 'Home Goods', imageUrl: 'homegoods.jpg' },
    { name: 'Accessories', imageUrl: 'accessories.jpg' }
  ],
  testimonials: [
    { name: 'John Doe', feedback: 'Great products and fast delivery!' },
    { name: 'Jane Smith', feedback: 'High quality and stylish items.' },
    { name: 'Sam Wilson', feedback: 'Excellent customer service.' }
  ]
};

const App = () => {
  useEffect(() => {
    AOS.init({ duration: 1000, once: false });
  }, []);

  useEffect(() => {
    AOS.refresh();
  });

  return (
    <div className={styles.container}>
      {/* Hero Section */}
      <section className={styles.hero} data-aos="fade-up" >
        <h1 className={styles.heroTitle}>{content.hero.title}</h1>
        <p className={styles.heroSubtitle}>{content.hero.subtitle}</p>
        <a href='#products-section'><button className={styles.heroButton} >{content.hero.buttonText}</button></a>
      </section>

      {/* Products Section */}
      <section className={styles.featured} data-aos="fade-up" id="products-section">
        <h2 className={styles.featuredTitle}>Featured Products</h2>
        <div className={styles.productsGrid}>
          {content.products.map(product => (
            <div key={product.id} className={styles.productCard}>
              <div className={styles.productImageContainer}>
                <img   src={require(`./assets/images/${product.imageUrl}`)}
 alt={product.name} className={styles.productImage} />
              </div>
              <div className={styles.productDetails}>
                <h3 className={styles.productName}>{product.name}</h3>
                <p className={styles.productPrice}>{product.price}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Categories Section */}
      <section className={styles.categories} data-aos="zoom-in">
        <h2 className={styles.categoryTitle}>Explore Our Categories</h2>
        <div className={styles.categoryGrid}>
          {content.categories.map((category, index) => (
            <div key={index} className={styles.categoryCard}>
              <div className={styles.categoryImageContainer}>
                <img  src={require(`./assets/images/${category.imageUrl}`)} alt={category.name} className={styles.categoryImage} />
              </div>
              <div className={styles.categoryOverlay}>
                <h3 className={styles.categoryName}>{category.name}</h3>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Testimonials Section */}
      <section className={styles.testimonials} data-aos="fade-up">
        <h2 className={styles.testimonialTitle}>What Our Customers Say</h2>
        <div className={styles.testimonialGrid}>
          {content.testimonials.map((testimonial, index) => (
            <div key={index} className={styles.testimonialCard}>
              <p className={styles.testimonialFeedback}>&ldquo;{testimonial.feedback}&rdquo;</p>
              <p className={styles.testimonialName}>- {testimonial.name}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className={styles.footer} data-aos="fade-up">
        <div className={styles.footerSocialLinks}>
          <a href="#facebook">Facebook</a>
          <a href="#twitter">Twitter</a>
          <a href="#instagram">Instagram</a>
        </div>
        <p className={styles.footerCopyright}>
          &copy; {new Date().getFullYear()} Your E-Commerce Store. All rights reserved.
        </p>
      </footer>
    </div>
  );
};

export default App;
